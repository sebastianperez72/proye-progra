#ifndef UTEC_ALGEBRA_TENSOR_BACKEND_H
#define UTEC_ALGEBRA_TENSOR_BACKEND_H

#include "shape.h"
#include <vector>
#include <stdexcept>
#include <array>

namespace utec::tf {

template <typename T>
class Tensor {
private:
    Shape shape_;
    std::vector<T> data_;

public:
    Tensor() = default;

    Tensor(Shape s, std::vector<T> d) : shape_(std::move(s)), data_(std::move(d)) {
        if (data_.size() != shape_.total_size()) {
            throw std::invalid_argument("Datos no coinciden con total_size().");
        }
    }

    Tensor(Shape s, T fill_value) : shape_(std::move(s)), data_(shape_.total_size(), fill_value) {}

    static Tensor zeros(const Shape& s) { return Tensor(s, T(0)); }
    static Tensor ones(const Shape& s) { return Tensor(s, T(1)); }
    static Tensor from_data(const Shape& s, const std::vector<T>& data) { return Tensor(s, data); }

    std::size_t rank() const { return shape_.rank(); }
    std::size_t total_size() const { return shape_.total_size(); }
    std::size_t numel() const { return shape_.total_size(); }
    std::size_t size() const { return data_.size(); } // Agregado para el autograder
    Shape shape() const { return shape_; }

    const std::vector<T>& data() const { return data_; }
    std::vector<T>& data() { return data_; }

    T& operator[](std::size_t idx) { return data_[idx]; }
    const T& operator[](std::size_t idx) const { return data_[idx]; }

    T& at(const std::vector<int>& indices) {
        if (indices.size() != shape_.rank()) throw std::invalid_argument("Rango de indices incorrecto.");
        std::size_t flat_idx = 0;
        std::size_t stride = 1;
        for (int i = shape_.rank() - 1; i >= 0; --i) {
            if (indices[i] < 0 || indices[i] >= shape_[i]) throw std::out_of_range("Indice fuera de limites.");
            flat_idx += indices[i] * stride;
            stride *= shape_[i];
        }
        return data_[flat_idx];
    }

    const T& at(const std::vector<int>& indices) const {
        if (indices.size() != shape_.rank()) throw std::invalid_argument("Rango de indices incorrecto.");
        std::size_t flat_idx = 0;
        std::size_t stride = 1;
        for (int i = shape_.rank() - 1; i >= 0; --i) {
            if (indices[i] < 0 || indices[i] >= shape_[i]) throw std::out_of_range("Indice fuera de limites.");
            flat_idx += indices[i] * stride;
            stride *= shape_[i];
        }
        return data_[flat_idx];
    }

    void reshape(const Shape& new_shape) {
        if (new_shape.total_size() != this->total_size()) {
            throw std::invalid_argument("Nuevo Shape no preserva total_size.");
        }
        shape_ = new_shape;
    }

    Tensor operator+(const Tensor& other) const {
        if (shape_ != other.shape_) throw std::invalid_argument("Shapes incompatibles para suma.");
        std::vector<T> new_data(data_.size());
        for (std::size_t i = 0; i < data_.size(); ++i) new_data[i] = data_[i] + other.data_[i];
        return Tensor(shape_, std::move(new_data));
    }

    Tensor operator-(const Tensor& other) const {
        if (shape_ != other.shape_) throw std::invalid_argument("Shapes incompatibles para resta.");
        std::vector<T> new_data(data_.size());
        for (std::size_t i = 0; i < data_.size(); ++i) new_data[i] = data_[i] - other.data_[i];
        return Tensor(shape_, std::move(new_data));
    }
};

} // namespace utec::tf

#endif // UTEC_ALGEBRA_TENSOR_BACKEND_H