#ifndef UTEC_ALGEBRA_SHAPE_H
#define UTEC_ALGEBRA_SHAPE_H

#include <vector>
#include <initializer_list>
#include <stdexcept>
#include <numeric>
#include <functional>

namespace utec::tf {

    class Shape {
    private:
        std::vector<int> dims_;

        void validate() const {
            for (int dim : dims_) {
                if (dim <= 0) {
                    throw std::invalid_argument("Las dimensiones deben ser mayores a cero.");
                }
            }
        }

    public:
        Shape() = default;
        Shape(std::initializer_list<int> list) : dims_(list) { validate(); }
        explicit Shape(std::vector<int> vec) : dims_(std::move(vec)) { validate(); }

        std::size_t rank() const { return dims_.size(); }
        std::size_t size() const { return dims_.size(); } // Agregado para el autograder

        std::size_t total_size() const {
            if (dims_.empty()) return 0;
            return std::accumulate(dims_.begin(), dims_.end(), 1ULL, std::multiplies<std::size_t>());
        }

        std::size_t numel() const { return total_size(); }

        int operator[](std::size_t i) const {
            if (i >= dims_.size()) throw std::out_of_range("Indice fuera de rango.");
            return dims_[i];
        }

        bool operator==(const Shape& other) const { return dims_ == other.dims_; }
        bool operator!=(const Shape& other) const { return !(*this == other); }
        const std::vector<int>& dims() const { return dims_; }
    };

} // namespace utec::tf

#endif // UTEC_ALGEBRA_SHAPE_H