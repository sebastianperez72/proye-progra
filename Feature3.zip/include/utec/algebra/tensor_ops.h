#ifndef UTEC_ALGEBRA_TENSOR_OPS_H
#define UTEC_ALGEBRA_TENSOR_OPS_H

#include "tensor_backend.h"

namespace utec::tf {

namespace algebra {

template <typename T>
Tensor<T> transpose2d(const Tensor<T>& m) {
    if (m.shape().rank() != 2) throw std::invalid_argument("Transpose2D requiere rango 2.");
    int rows = m.shape()[0];
    int cols = m.shape()[1];
    std::vector<T> res_data(m.numel());

    const auto& m_data = m.data();
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            res_data[j * rows + i] = m_data[i * cols + j];
        }
    }
    return Tensor<T>::from_data(Shape{cols, rows}, res_data);
}

template <typename T>
Tensor<T> multiply(const Tensor<T>& a, const Tensor<T>& b) {
    if (a.shape() != b.shape()) throw std::invalid_argument("Shapes incompatibles para multiply.");
    std::vector<T> res(a.numel());
    const auto& a_data = a.data();
    const auto& b_data = b.data();
    for (std::size_t i = 0; i < res.size(); ++i) {
        res[i] = a_data[i] * b_data[i];
    }
    return Tensor<T>::from_data(a.shape(), res);
}

template <typename T>
Tensor<T> matmul(const Tensor<T>& a, const Tensor<T>& b) {
    if (a.shape().rank() != 2 || b.shape().rank() != 2) throw std::invalid_argument("Matmul requiere rango 2.");
    if (a.shape()[1] != b.shape()[0]) throw std::invalid_argument("Dimensiones internas incompatibles.");

    int M = a.shape()[0], K = a.shape()[1], N = b.shape()[1];
    std::vector<T> res_data(M * N, 0);

    const auto& a_data = a.data();
    const auto& b_data = b.data();

    for (int i = 0; i < M; ++i) {
        for (int k = 0; k < K; ++k) {
            T a_val = a_data[i * K + k]; // Acceso lineal
            for (int j = 0; j < N; ++j) {
                res_data[i * N + j] += a_val * b_data[k * N + j];
            }
        }
    }
    return Tensor<T>::from_data(Shape{M, N}, res_data);
}

} // namespace algebra

namespace ops {
    template <typename T>
    Tensor<T> transpose2d(const Tensor<T>& m) { return algebra::transpose2d(m); }

    template <typename T>
    Tensor<T> multiply(const Tensor<T>& a, const Tensor<T>& b) { return algebra::multiply(a, b); }

    template <typename T>
    Tensor<T> matmul(const Tensor<T>& a, const Tensor<T>& b) { return algebra::matmul(a, b); }
} // namespace ops

} // namespace utec::tf

#endif // UTEC_ALGEBRA_TENSOR_OPS_H