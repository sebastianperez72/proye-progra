#ifndef UTEC_NN_NN_POOLING_H
#define UTEC_NN_NN_POOLING_H

#include "nn_interfaces.h"
#include <array>
#include <stdexcept>
#include <algorithm>

namespace utec::tf::layers {

class MaxPooling2D : public Layer {
private:
    std::array<int, 2> pool_size_;
    std::array<int, 2> strides_;
    Shape input_shape_;
    Shape output_shape_;

public:
    explicit MaxPooling2D(std::array<int, 2> pool_size)
        : pool_size_(pool_size), strides_(pool_size) {
        if (pool_size[0] <= 0 || pool_size[1] <= 0) {
            throw std::invalid_argument("Pool size dimensions must be positive.");
        }
    }

    void build(const Shape& input_shape) override {
        input_shape_ = input_shape;
        if (input_shape_.rank() != 3) {
            throw std::invalid_argument("MaxPooling2D expects rank 3 input shape (H, W, C).");
        }

        int in_h = input_shape_[0];
        int in_w = input_shape_[1];
        int in_c = input_shape_[2];

        if (in_h % pool_size_[0] != 0 || in_w % pool_size_[1] != 0) {
            throw std::invalid_argument("Pool size must exactly divide input dimensions.");
        }

        int out_h = in_h / pool_size_[0];
        int out_w = in_w / pool_size_[1];

        output_shape_ = Shape{out_h, out_w, in_c};
    }

    Tensor<float> forward(const Tensor<float>& x) override {
        if (x.rank() != 4) {
            throw std::invalid_argument("MaxPooling2D expects rank 4 batch input.");
        }

        int batch = x.shape()[0];
        int in_h = x.shape()[1];
        int in_w = x.shape()[2];
        int channels = x.shape()[3];

        int ph = pool_size_[0];
        int pw = pool_size_[1];
        int sh = strides_[0];
        int sw = strides_[1];

        int out_h = in_h / ph;
        int out_w = in_w / pw;

        Tensor<float> out(Shape{batch, out_h, out_w, channels}, 0.0f);

        for (int b = 0; b < batch; ++b) {
            for (int oh = 0; oh < out_h; ++oh) {
                for (int ow = 0; ow < out_w; ++ow) {
                    for (int c = 0; c < channels; ++c) {
                        float max_val = x.at({b, oh * sh, ow * sw, c});
                        for (int kh = 0; kh < ph; ++kh) {
                            for (int kw = 0; kw < pw; ++kw) {
                                float val = x.at({b, oh * sh + kh, ow * sw + kw, c});
                                if (val > max_val) {
                                    max_val = val;
                                }
                            }
                        }
                        out.at({b, oh, ow, c}) = max_val;
                    }
                }
            }
        }
        return out;
    }

    Shape output_shape() const override {
        return output_shape_;
    }

    std::unique_ptr<Layer> clone() const override {
        return std::make_unique<MaxPooling2D>(*this);
    }
};

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_POOLING_H