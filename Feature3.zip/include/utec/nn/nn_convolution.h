#ifndef UTEC_NN_NN_CONVOLUTION_H
#define UTEC_NN_NN_CONVOLUTION_H

#include "nn_interfaces.h"
#include "nn_activation.h"
#include "nn_ops.h"
#include <array>
#include <stdexcept>

namespace utec::tf::layers {

class Conv2D : public Layer {
private:
    int filters_;
    std::array<int, 2> kernel_size_;
    Activation activation_;
    Shape input_shape_;
    Shape output_shape_;
    Tensor<float> weights_;
    Tensor<float> bias_;

public:
    Conv2D(int filters, std::array<int, 2> kernel_size, Activation activation = Activation::Linear)
        : filters_(filters), kernel_size_(kernel_size), activation_(activation) {
        if (filters <= 0 || kernel_size[0] <= 0 || kernel_size[1] <= 0) {
            throw std::invalid_argument("Filters and kernel sizes must be positive.");
        }
    }

    void build(const Shape& input_shape) override {
        input_shape_ = input_shape;
        if (input_shape_.rank() != 3) {
            throw std::invalid_argument("Conv2D expects rank 3 input shape (H, W, C).");
        }

        int in_h = input_shape_[0];
        int in_w = input_shape_[1];
        int in_c = input_shape_[2];

        int kh = kernel_size_[0];
        int kw = kernel_size_[1];

        if (in_h < kh || in_w < kw) {
            throw std::invalid_argument("Kernel size cannot be larger than input size.");
        }

        int out_h = in_h - kh + 1;
        int out_w = in_w - kw + 1;

        float val = 1.0f / static_cast<float>(kh * kw * in_c);
        weights_ = Tensor<float>(Shape{kh, kw, in_c, filters_}, val);

        bias_ = Tensor<float>(Shape{filters_}, 0.0f);

        output_shape_ = Shape{out_h, out_w, filters_};
    }

    Tensor<float> forward(const Tensor<float>& x) override {
        if (x.rank() != 4) {
            throw std::invalid_argument("Conv2D expects rank 4 batch input.");
        }

        Tensor<float> conv_res = ops::conv2d(x, weights_, Strides{1, 1}, Padding::Valid);

        int batch = conv_res.shape()[0];
        int oh = conv_res.shape()[1];
        int ow = conv_res.shape()[2];
        int filters = conv_res.shape()[3];

        for (int b = 0; b < batch; ++b) {
            for (int h = 0; h < oh; ++h) {
                for (int w = 0; w < ow; ++w) {
                    for (int f = 0; f < filters; ++f) {
                        conv_res.at({b, h, w, f}) += bias_.at({f});
                    }
                }
            }
        }

        return apply_activation(conv_res, activation_);
    }

    Shape output_shape() const override {
        return output_shape_;
    }

    std::map<std::string, Tensor<float>> parameters() const override {
        std::map<std::string, Tensor<float>> params;
        params["weights"] = weights_;
        params["bias"] = bias_;
        return params;
    }

    std::unique_ptr<Layer> clone() const override {
        return std::make_unique<Conv2D>(*this);
    }
};

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_CONVOLUTION_H