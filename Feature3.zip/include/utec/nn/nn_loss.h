#ifndef UTEC_NN_NN_LOSS_H
#define UTEC_NN_NN_LOSS_H

#include "utec/algebra/tensor_backend.h"
#include <cmath>
#include <stdexcept>

namespace utec::tf {
    namespace losses {

        class CategoricalCrossentropy {
        public:
            CategoricalCrossentropy() = default;

            float operator()(const Tensor<float>& y_true, const Tensor<float>& y_pred) const {
                if (y_true.shape() != y_pred.shape()) {
                    throw std::invalid_argument("Shapes incompatibles en CategoricalCrossentropy.");
                }

                float total_loss = 0.0f;
                int batch = y_pred.shape()[0];
                int classes = y_pred.shape()[1];

                for (int i = 0; i < batch; ++i) {
                    for (int j = 0; j < classes; ++j) {
                        if (y_true.at({i, j}) == 1.0f) {
                            float prob = std::max(y_pred.at({i, j}), 1e-7f);
                            total_loss -= std::log(prob);
                        }
                    }
                }
                return total_loss / batch;
            }
        };

    } // namespace losses
} // namespace utec::tf

#endif // UTEC_NN_NN_LOSS_H