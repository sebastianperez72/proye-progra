#ifndef UTEC_NN_NN_ACTIVATION_H
#define UTEC_NN_NN_ACTIVATION_H

#include "utec/algebra/tensor_backend.h"
#include <cmath>
#include <algorithm>
#include <stdexcept>

namespace utec::tf {

    enum class Activation { Linear, Relu, Softmax };

    inline Tensor<float> apply_activation(const Tensor<float>& input, Activation act) {
        if (act == Activation::Linear) {
            return input;
        }
        else if (act == Activation::Relu) {
            Tensor<float> result = input;
            for (std::size_t i = 0; i < result.size(); ++i) {
                if (result[i] < 0.0f) result[i] = 0.0f;
            }
            return result;
        }
        else if (act == Activation::Softmax) {
            if (input.rank() != 2) throw std::invalid_argument("Softmax requiere rango 2.");

            int batch = input.shape()[0];
            int classes = input.shape()[1];
            Tensor<float> result = Tensor<float>::zeros(input.shape());

            for (int i = 0; i < batch; ++i) {
                float max_val = input.at({i, 0});
                for (int j = 1; j < classes; ++j) {
                    max_val = std::max(max_val, input.at({i, j}));
                }

                float sum = 0.0f;
                for (int j = 0; j < classes; ++j) {
                    float exp_val = std::exp(input.at({i, j}) - max_val);
                    result.at({i, j}) = exp_val;
                    sum += exp_val;
                }
                for (int j = 0; j < classes; ++j) {
                    result.at({i, j}) /= sum;
                }
            }
            return result;
        }
        return input;
    }

} // namespace utec::tf

#endif // UTEC_NN_NN_ACTIVATION_H