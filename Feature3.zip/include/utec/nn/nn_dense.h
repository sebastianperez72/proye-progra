#ifndef UTEC_NN_NN_DENSE_H
#define UTEC_NN_NN_DENSE_H

#include "nn_interfaces.h"
#include "nn_activation.h"
#include "utec/algebra/tensor_ops.h"
#include <stdexcept>

namespace utec::tf::layers {

class Dense : public Layer {
private:
    int units_;
    Activation activation_;
    Shape input_shape_;
    Shape output_shape_;
    Tensor<float> weights_;
    Tensor<float> bias_;

public:
    Dense(int units, Activation activation = Activation::Linear)
        : units_(units), activation_(activation) {
        if (units <= 0) {
            throw std::invalid_argument("Units must be greater than 0.");
        }
    }

    void build(const Shape& input_shape) override {
        input_shape_ = input_shape;
        if (input_shape_.rank() == 0) {
            throw std::invalid_argument("Input shape cannot be empty.");
        }
        int in_features = input_shape_[0];

        float val = 1.0f / static_cast<float>(in_features);
        weights_ = Tensor<float>(Shape{in_features, units_}, val);

        bias_ = Tensor<float>(Shape{units_}, 0.0f);

        output_shape_ = Shape{units_};
    }

    Tensor<float> forward(const Tensor<float>& x) override {
        if (x.rank() != 2) {
            throw std::invalid_argument("Dense layer expects rank 2 input.");
        }

        Tensor<float> matmul_res = algebra::matmul(x, weights_);
        int batch = matmul_res.shape()[0];
        int units = matmul_res.shape()[1];

        for (int i = 0; i < batch; ++i) {
            for (int j = 0; j < units; ++j) {
                matmul_res.at({i, j}) += bias_.at({j});
            }
        }

        return apply_activation(matmul_res, activation_);
    }

    Shape output_shape() const override {
        return output_shape_;
    }

    std::map<std::string, Tensor<float>> parameters() const override {
        std::map<std::string, Tensor<float>> params;
        params["weights"] = weights_;
        params["bias"] = bias_;
        return params;
    }

    std::unique_ptr<Layer> clone() const override {
        return std::make_unique<Dense>(*this);
    }
};

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_DENSE_H