#ifndef UTEC_NN_NN_OPTIMIZER_H
#define UTEC_NN_NN_OPTIMIZER_H

namespace utec::tf::optimizers {

    struct SGD {
        float learning_rate;

        explicit SGD(float lr = 0.01f) : learning_rate(lr) {}
    };

} // namespace utec::tf::optimizers

#endif // UTEC_NN_NN_OPTIMIZER_H