#ifndef UTEC_NN_NEURAL_NETWORK_H
#define UTEC_NN_NEURAL_NETWORK_H

#include "nn_interfaces.h"
#include "nn_activation.h"
#include "nn_ops.h"
#include "nn_dense.h"
#include "nn_convolution.h"
#include "nn_pooling.h"
#include "nn_flatten.h"
#include "nn_loss.h"
#include "nn_optimizer.h"

#include <vector>
#include <memory>
#include <string>
#include <map>
#include <stdexcept>

namespace utec::tf {

class Sequential {
private:
    std::vector<std::unique_ptr<Layer>> layers_;
    bool compiled_ = false;
    optimizers::SGD optimizer_;
    losses::CategoricalCrossentropy loss_;

public:
    Sequential() = default;

    bool compiled() const { return compiled_; }

    template <typename LayerT>
    void add(LayerT layer) {
        auto cloned = std::make_unique<LayerT>(layer);

        if (layers_.empty()) {
            cloned->build(Shape{});
        } else {
            cloned->build(layers_.back()->output_shape());
        }

        layers_.push_back(std::move(cloned));
    }

    void compile(optimizers::SGD optimizer, losses::CategoricalCrossentropy loss) {
        if (layers_.empty()) {
            throw std::runtime_error("Cannot compile an empty model.");
        }
        optimizer_ = optimizer;
        loss_ = loss;
        compiled_ = true;
    }

    Tensor<float> predict(const Tensor<float>& batch) {
        if (layers_.empty()) {
            throw std::runtime_error("Model has no layers.");
        }

        Tensor<float> current = batch;
        for (const auto& layer : layers_) {
            current = layer->forward(current);
        }
        return current;
    }

    std::map<std::string, Tensor<float>> parameters() const {
        std::map<std::string, Tensor<float>> all_params;
        int conv_count = 0;
        int dense_count = 0;

        for (const auto& layer : layers_) {
            auto params = layer->parameters();
            if (!params.empty()) {
                std::string prefix = "";
                if (params.count("weights")) {
                    if (params.at("weights").rank() == 4) {
                        prefix = "conv2d_" + std::to_string(conv_count++) + "/";
                    } else if (params.at("weights").rank() == 2) {
                        prefix = "dense_" + std::to_string(dense_count++) + "/";
                    }
                }

                for (const auto& [key, val] : params) {
                    all_params[prefix + key] = val;
                }
            }
        }
        return all_params;
    }
};

} // namespace utec::tf

#endif // UTEC_NN_NEURAL_NETWORK_H