#ifndef UTEC_NN_NN_FLATTEN_H
#define UTEC_NN_NN_FLATTEN_H

#include "nn_interfaces.h"
#include "nn_ops.h"
#include <stdexcept>

namespace utec::tf::layers {

    class Flatten : public Layer {
    private:
        Shape input_shape_;
        Shape output_shape_;

    public:
        Flatten() = default;

        void build(const Shape& input_shape) override {
            input_shape_ = input_shape;
            if (input_shape_.rank() == 0) {
                throw std::invalid_argument("Input shape cannot be empty.");
            }
            int total = 1;
            for (std::size_t i = 0; i < input_shape_.rank(); ++i) {
                total *= input_shape_[i];
            }
            output_shape_ = Shape{total};
        }

        Tensor<float> forward(const Tensor<float>& x) override {
            return ops::flatten_batch(x);
        }

        Shape output_shape() const override {
            return output_shape_;
        }

        std::unique_ptr<Layer> clone() const override {
            return std::make_unique<Flatten>(*this);
        }
    };

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_FLATTEN_H