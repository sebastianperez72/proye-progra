#ifndef UTEC_NN_NN_OPS_H
#define UTEC_NN_NN_OPS_H

#include "utec/algebra/tensor_backend.h"
#include "utec/algebra/tensor_ops.h"
#include <stdexcept>

namespace utec::tf {

struct Strides { int rows, cols; };
enum class Padding { Valid };

namespace ops {

template <typename T>
Tensor<T> flatten_batch(const Tensor<T>& x) {
    if (x.rank() < 2) throw std::invalid_argument("Flatten requiere rank >= 2.");
    int batch = x.shape()[0];
    int remaining = static_cast<int>(x.total_size() / batch);

    Tensor<T> result = x;
    result.reshape(Shape{batch, remaining});
    return result;
}

template <typename T>
Tensor<T> conv2d(const Tensor<T>& input, const Tensor<T>& kernel, Strides s = Strides{1, 1}, Padding p = Padding::Valid) {
    if (s.rows <= 0 || s.cols <= 0) throw std::invalid_argument("Strides deben ser positivos.");
    if (input.rank() != 4 || kernel.rank() != 4) throw std::invalid_argument("Rank debe ser 4.");
    if (input.shape()[3] != kernel.shape()[2]) throw std::invalid_argument("Canales no coinciden.");

    int N_batch = input.shape()[0], Hi = input.shape()[1], Wi = input.shape()[2], Ci = input.shape()[3];
    int Hk = kernel.shape()[0], Wk = kernel.shape()[1], Co = kernel.shape()[3];

    int Ho = (Hi - Hk) / s.rows + 1;
    int Wo = (Wi - Wk) / s.cols + 1;
    if (Ho <= 0 || Wo <= 0) throw std::invalid_argument("Kernel más grande que la entrada.");

    Tensor<T> out(Shape{N_batch, Ho, Wo, Co}, T(0));
    const auto& in_data = input.data();
    const auto& k_data = kernel.data();
    auto& out_data = out.data();

    for (int n = 0; n < N_batch; ++n) {
        for (int oh = 0; oh < Ho; ++oh) {
            for (int ow = 0; ow < Wo; ++ow) {
                for (int oc = 0; oc < Co; ++oc) {
                    T sum = 0;
                    for (int kh = 0; kh < Hk; ++kh) {
                        int in_h = oh * s.rows + kh;
                        for (int kw = 0; kw < Wk; ++kw) {
                            int in_w = ow * s.cols + kw;
                            for (int cc = 0; cc < Ci; ++cc) {
                                int in_idx = ((n * Hi + in_h) * Wi + in_w) * Ci + cc;
                                int k_idx = ((kh * Wk + kw) * Ci + cc) * Co + oc;
                                sum += in_data[in_idx] * k_data[k_idx];
                            }
                        }
                    }
                    out_data[((n * Ho + oh) * Wo + ow) * Co + oc] = sum;
                }
            }
        }
    }
    return out;
}

} // namespace ops
} // namespace utec::tf

#endif // UTEC_NN_NN_OPS_H