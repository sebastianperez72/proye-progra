#ifndef UTEC_ALGEBRA_TENSOR_BACKEND_H
#define UTEC_ALGEBRA_TENSOR_BACKEND_H

#include "shape.h"
#include <vector>
#include <stdexcept>
#include <array>

namespace utec::tf {

template <typename T>
class Tensor {
private:
    Shape shape_;
    std::vector<T> data_;

    // Constructor privado para fábricas
    Tensor(Shape s, std::vector<T> d) : shape_(std::move(s)), data_(std::move(d)) {}

    // Helper para convertir N índices en 1 índice plano contiguo
    template <std::size_t N>
    std::size_t compute_index(const std::array<int, N>& indices) const {
        if (N != shape_.rank()) {
            throw std::invalid_argument("Cantidad de indices no coincide con el rank del tensor.");
        }
        std::size_t flat_idx = 0;
        std::size_t stride = 1;
        // Calculamos de atras hacia adelante (Row-major order)
        for (int i = shape_.rank() - 1; i >= 0; --i) {
            if (indices[i] < 0 || indices[i] >= shape_[i]) {
                throw std::out_of_range("Indice fuera de los limites de la dimension.");
            }
            flat_idx += indices[i] * stride;
            stride *= shape_[i];
        }
        return flat_idx;
    }

public:
    // Question #2 & #3 - Factories
    static Tensor zeros(const Shape& s) {
        return Tensor(s, std::vector<T>(s.numel(), T(0)));
    }

    static Tensor ones(const Shape& s) {
        return Tensor(s, std::vector<T>(s.numel(), T(1)));
    }

    // Question #5 - Factory from data
    static Tensor from_data(const Shape& s, const std::vector<T>& data) {
        if (data.size() != s.numel()) {
            throw std::invalid_argument("La cantidad de datos no coincide con numel().");
        }
        return Tensor(s, data);
    }

    // Question #4 - Metadata
    std::size_t rank() const { return shape_.rank(); }
    std::size_t numel() const { return shape_.numel(); }
    Shape shape() const { return shape_; }

    // Question #5 - Data access (Variadic Templates)
    template <typename... Args>
    T& operator()(Args... args) {
        std::array<int, sizeof...(Args)> indices = { static_cast<int>(args)... };
        return data_[compute_index(indices)];
    }

    template <typename... Args>
    const T& operator()(Args... args) const {
        std::array<int, sizeof...(Args)> indices = { static_cast<int>(args)... };
        return data_[compute_index(indices)];
    }

    // Question #6 - Reshape
    Tensor reshape(const Shape& new_shape) const {
        if (new_shape.numel() != this->numel()) {
            throw std::invalid_argument("El nuevo Shape no preserva la cantidad de elementos (numel).");
        }
        return Tensor(new_shape, data_);
    }

    // Question #7 - Suma elemento a elemento
    Tensor operator+(const Tensor& other) const {
        if (shape_ != other.shape_) {
            throw std::invalid_argument("Las formas de los tensores deben ser identicas para la suma.");
        }
        std::vector<T> new_data(data_.size());
        for (std::size_t i = 0; i < data_.size(); ++i) {
            new_data[i] = data_[i] + other.data_[i];
        }
        return Tensor(shape_, std::move(new_data));
    }
};

} // namespace utec::tf

#endif // UTEC_ALGEBRA_TENSOR_BACKEND_H