#ifndef UTEC_ALGEBRA_TENSOR_OPS_H
#define UTEC_ALGEBRA_TENSOR_OPS_H

#include "tensor_backend.h"
#include <cmath>
#include <stdexcept>

namespace utec::tf {

    template <typename T>
    bool allclose(const Tensor<T>& a, const Tensor<T>& b, float tol = 1e-4f) {
        if (a.shape() != b.shape()) return false;
        for (std::size_t i = 0; i < a.size(); ++i) {
            if (std::abs(a.data()[i] - b.data()[i]) > tol) return false;
        }
        return true;
    }

    namespace algebra {

        template <typename T>
        Tensor<T> matmul(const Tensor<T>& a, const Tensor<T>& b) {
            if (a.rank() != 2 || b.rank() != 2) throw std::invalid_argument("Matmul requiere rango 2.");
            if (a.shape()[1] != b.shape()[0]) throw std::invalid_argument("Dimensiones incompatibles.");

            int M = a.shape()[0];
            int K = a.shape()[1];
            int N = b.shape()[1];

            Tensor<T> c(Shape{M, N}, T(0));
            for (int i = 0; i < M; ++i) {
                for (int j = 0; j < N; ++j) {
                    T sum = 0;
                    for (int k = 0; k < K; ++k) {
                        sum += a.at({i, k}) * b.at({k, j});
                    }
                    c.at({i, j}) = sum;
                }
            }
            return c;
        }

        template <typename T>
        Tensor<T> transpose(const Tensor<T>& a) {
            if (a.rank() != 2) throw std::invalid_argument("Transpose requiere rango 2.");
            int rows = a.shape()[0];
            int cols = a.shape()[1];

            Tensor<T> res(Shape{cols, rows}, T(0));

            for (int i = 0; i < rows; ++i) {
                for (int j = 0; j < cols; ++j) {
                    res.at({j, i}) = a.at({i, j});
                }
            }
            return res;
        }

    } // namespace algebra
} // namespace utec::tf

#endif // UTEC_ALGEBRA_TENSOR_OPS_H