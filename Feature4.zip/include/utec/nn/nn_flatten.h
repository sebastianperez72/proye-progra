#ifndef UTEC_NN_NN_FLATTEN_H
#define UTEC_NN_NN_FLATTEN_H

#include "nn_interfaces.h"
#include <stdexcept>

namespace utec::tf::layers {

    class Flatten : public Layer {
    private:
        Shape input_shape_;
        Shape output_shape_;

    public:
        void build(const Shape& input_shape) override {
            input_shape_ = input_shape;
            int batch = input_shape[0];
            int features = input_shape.total_size() / batch;
            output_shape_ = Shape{batch, features};
        }

        Tensor<float> forward(const Tensor<float>& x) override {
            input_shape_ = x.shape();
            int batch = x.shape()[0];
            int features = x.total_size() / batch;
            return x.reshaped(Shape{batch, features});
        }

        Tensor<float> backward(const Tensor<float>& grad_output) override {
            return grad_output.reshaped(input_shape_);
        }

        Shape output_shape() const override { return output_shape_; }

        std::map<std::string, Tensor<float>> parameters() const override { return {}; }
        std::map<std::string, Tensor<float>> gradients() const override { return {}; }
        std::unique_ptr<Layer> clone() const override { return std::make_unique<Flatten>(*this); }
    };

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_FLATTEN_H