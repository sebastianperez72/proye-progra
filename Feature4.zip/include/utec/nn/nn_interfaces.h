#ifndef UTEC_NN_NN_INTERFACES_H
#define UTEC_NN_NN_INTERFACES_H

#include "utec/algebra/tensor_backend.h"
#include <map>
#include <string>
#include <memory>
#include <stdexcept>

namespace utec::tf {

    class Layer {
    public:
        virtual ~Layer() = default;
        virtual void build(const Shape& input_shape) = 0;
        virtual Tensor<float> forward(const Tensor<float>& input) = 0;

        // NUEVO FEATURE 4: Soporte para propagación hacia atrás y exposición de gradientes
        virtual Tensor<float> backward(const Tensor<float>& grad_output) = 0;

        virtual Shape output_shape() const = 0;

        virtual std::map<std::string, Tensor<float>> parameters() const { return {}; }
        virtual std::map<std::string, Tensor<float>> gradients() const { return {}; }

        virtual std::unique_ptr<Layer> clone() const = 0;
    };

    namespace layers {

        class Input : public Layer {
        private:
            Shape sample_shape_;

        public:
            explicit Input(Shape sample_shape) : sample_shape_(std::move(sample_shape)) {
                if (sample_shape_.rank() == 0) {
                    throw std::invalid_argument("Input shape cannot be empty.");
                }
            }

            void build(const Shape& /*input_shape*/) override {}

            Tensor<float> forward(const Tensor<float>& input) override {
                return input;
            }

            Tensor<float> backward(const Tensor<float>& grad_output) override {
                // Input no tiene gradientes que modificar, solo pasa el flujo
                return grad_output;
            }

            Shape output_shape() const override {
                return sample_shape_;
            }

            std::unique_ptr<Layer> clone() const override {
                return std::make_unique<Input>(*this);
            }
        };

    } // namespace layers
} // namespace utec::tf

#endif // UTEC_NN_NN_INTERFACES_H