#ifndef UTEC_NN_NEURAL_NETWORK_H
#define UTEC_NN_NEURAL_NETWORK_H

#include "nn_graph.h"
#include "nn_optimizer.h"
#include "nn_loss.h"
#include "nn_activation.h"
#include "nn_dense.h"
#include "nn_convolution.h"
#include "nn_pooling.h"
#include "nn_flatten.h"
#include "utec/algebra/tensor_backend.h"
#include "utec/algebra/tensor_ops.h"
#include <string>
#include <vector>
#include <map>
#include <stdexcept>
#include <iostream>

namespace utec::tf {

struct FitOptions {
    int epochs = 1;
    int batch_size = 32;
    bool verbose = true;
};

struct History {
    std::vector<float> loss;
};

struct EvalResult {
    float loss;
    float accuracy;
};

class Sequential {
private:
    SequentialGraph graph_;
    bool compiled_ = false;
    optimizers::SGD optimizer_;
    losses::CategoricalCrossentropy loss_fn_;

public:
    Sequential() = default;

    template <typename LayerT>
    void add(const LayerT& layer) { graph_.add(layer.clone()); }

    void compile(optimizers::SGD optimizer, losses::CategoricalCrossentropy loss_fn) {
        optimizer_ = optimizer;
        loss_fn_ = loss_fn;
        compiled_ = true;
    }

    Tensor<float> predict(const Tensor<float>& x) {
        if (!compiled_) throw std::logic_error("Not compiled");
        return graph_.forward(x);
    }

    void backward() {
        if (!compiled_) throw std::logic_error("Not compiled");
    }

    Tensor<float> backward(const Tensor<float>& grad) {
        if (!compiled_) throw std::logic_error("Not compiled");
        return graph_.backward(grad);
    }

    std::map<std::string, Tensor<float>> parameters() const {
        std::map<std::string, Tensor<float>> all_params;
        int conv_idx = 0, dense_idx = 0;
        for (const auto& layer : graph_.layers()) {
            std::string prefix;
            if (dynamic_cast<layers::Conv2D*>(layer.get())) prefix = "conv2d_" + std::to_string(conv_idx++);
            else if (dynamic_cast<layers::Dense*>(layer.get())) prefix = "dense_" + std::to_string(dense_idx++);
            else continue;

            for (const auto& [name, tensor] : layer->parameters()) {
                all_params[prefix + "/" + name] = tensor;
            }
        }
        return all_params;
    }

    std::map<std::string, Tensor<float>> last_gradients() const {
        std::map<std::string, Tensor<float>> all_grads;
        int conv_idx = 0, dense_idx = 0;
        for (const auto& layer : graph_.layers()) {
            std::string prefix;
            if (dynamic_cast<layers::Conv2D*>(layer.get())) prefix = "conv2d_" + std::to_string(conv_idx++);
            else if (dynamic_cast<layers::Dense*>(layer.get())) prefix = "dense_" + std::to_string(dense_idx++);
            else continue;

            for (const auto& [name, tensor] : layer->gradients()) {
                all_grads[prefix + "/" + name] = tensor;
            }
        }
        return all_grads;
    }

    History fit(const Tensor<float>& x, const Tensor<float>& y, FitOptions options = {}) {
        if (!compiled_) throw std::logic_error("Not compiled");
        History history;
        float lr = optimizer_.learning_rate;

        for (int epoch = 0; epoch < options.epochs; ++epoch) {
            Tensor<float> y_pred = graph_.forward(x);
            history.loss.push_back(loss_fn_(y, y_pred));

            Tensor<float> grad = loss_fn_.backward(y, y_pred);
            graph_.backward(grad);

            for (const auto& layer : graph_.layers()) {
                auto params = layer->parameters();
                auto grads = layer->gradients();
                if (params.empty()) continue;

                std::vector<float> w_data = params.at("weights").data();
                std::vector<float> b_data = params.at("bias").data();
                const std::vector<float>& gw_data = grads.at("weights").data();
                const std::vector<float>& gb_data = grads.at("bias").data();

                for (std::size_t i = 0; i < w_data.size(); ++i) w_data[i] -= lr * gw_data[i];
                for (std::size_t i = 0; i < b_data.size(); ++i) b_data[i] -= lr * gb_data[i];

                if (auto dense = dynamic_cast<layers::Dense*>(layer.get())) {
                    dense->set_weights(Tensor<float>::from_data(params.at("weights").shape(), w_data));
                    dense->set_bias(Tensor<float>::from_data(params.at("bias").shape(), b_data));
                } else if (auto conv = dynamic_cast<layers::Conv2D*>(layer.get())) {
                    conv->set_weights(Tensor<float>::from_data(params.at("weights").shape(), w_data));
                    conv->set_bias(Tensor<float>::from_data(params.at("bias").shape(), b_data));
                }
            }
        }
        return history;
    }

    EvalResult evaluate(const Tensor<float>& x, const Tensor<float>& y) {
        if (!compiled_) throw std::runtime_error("Not compiled");
        Tensor<float> y_pred = graph_.forward(x);
        float loss = loss_fn_(y, y_pred);
        return {loss, 0.0f};
    }
};

} // namespace utec::tf

using utec::tf::Tensor;
using utec::tf::Shape;

#endif // UTEC_NN_NEURAL_NETWORK_H