#ifndef UTEC_NN_NN_CONVOLUTION_H
#define UTEC_NN_NN_CONVOLUTION_H

#include "nn_interfaces.h"
#include "nn_activation.h"
#include "nn_ops.h"
#include <array>
#include <stdexcept>

namespace utec::tf::layers {

class Conv2D : public Layer {
private:
    int filters_;
    std::array<int, 2> kernel_size_;
    Activation activation_;
    Shape input_shape_;
    Shape output_shape_;
    Tensor<float> weights_;
    Tensor<float> bias_;

    Tensor<float> cached_input_;
    Tensor<float> cached_z_;
    Tensor<float> grad_weights_;
    Tensor<float> grad_bias_;

public:
    Conv2D(int filters, std::array<int, 2> kernel_size, Activation activation = Activation::Linear)
        : filters_(filters), kernel_size_(kernel_size), activation_(activation) {
        if (filters <= 0 || kernel_size[0] <= 0 || kernel_size[1] <= 0) {
            throw std::invalid_argument("Filters and kernel sizes must be positive.");
        }
    }

    void build(const Shape& input_shape) override {
        input_shape_ = input_shape;
        if (input_shape_.rank() != 3) throw std::invalid_argument("Conv2D expects rank 3 input shape (H, W, C).");

        int in_h = input_shape_[0], in_w = input_shape_[1], in_c = input_shape_[2];
        int kh = kernel_size_[0], kw = kernel_size_[1];

        if (in_h < kh || in_w < kw) throw std::invalid_argument("Kernel size cannot be larger than input size.");

        int out_h = in_h - kh + 1;
        int out_w = in_w - kw + 1;

        float val = 1.0f / static_cast<float>(kh * kw * in_c);
        weights_ = Tensor<float>(Shape{kh, kw, in_c, filters_}, val);
        bias_ = Tensor<float>(Shape{filters_}, 0.0f);

        grad_weights_ = Tensor<float>::zeros(weights_.shape());
        grad_bias_ = Tensor<float>::zeros(bias_.shape());

        output_shape_ = Shape{out_h, out_w, filters_};
    }

    void set_weights(const Tensor<float>& w) { weights_ = w; }
    void set_bias(const Tensor<float>& b) { bias_ = b; }

    Tensor<float> forward(const Tensor<float>& x) override {
        if (x.rank() != 4) throw std::invalid_argument("Conv2D expects rank 4 batch input.");
        cached_input_ = x;

        Tensor<float> z = ops::conv2d(x, weights_, Strides{1, 1}, Padding::Valid);

        int batch = z.shape()[0], oh = z.shape()[1], ow = z.shape()[2], f = z.shape()[3];
        for (int b = 0; b < batch; ++b) {
            for (int i = 0; i < oh; ++i) {
                for (int j = 0; j < ow; ++j) {
                    for (int k = 0; k < f; ++k) {
                        z.at({b, i, j, k}) += bias_.at({k});
                    }
                }
            }
        }

        cached_z_ = z;
        return apply_activation(z, activation_);
    }

    Tensor<float> backward(const Tensor<float>& grad_output) override {
        Tensor<float> dz = apply_activation_derivative(cached_z_, activation_, grad_output);

        int batch = cached_input_.shape()[0];
        int in_c = cached_input_.shape()[3];
        int kh = weights_.shape()[0], kw = weights_.shape()[1], filters = weights_.shape()[3];
        int out_h = dz.shape()[1], out_w = dz.shape()[2];

        grad_weights_ = Tensor<float>::zeros(weights_.shape());
        grad_bias_ = Tensor<float>::zeros(bias_.shape());
        Tensor<float> dx = Tensor<float>::zeros(cached_input_.shape());

        for (int b = 0; b < batch; ++b) {
            for (int oh = 0; oh < out_h; ++oh) {
                for (int ow = 0; ow < out_w; ++ow) {
                    for (int f = 0; f < filters; ++f) {
                        float dZ_val = dz.at({b, oh, ow, f});
                        grad_bias_.at({f}) += dZ_val;

                        for (int i = 0; i < kh; ++i) {
                            for (int j = 0; j < kw; ++j) {
                                for (int c = 0; c < in_c; ++c) {
                                    grad_weights_.at({i, j, c, f}) += cached_input_.at({b, oh + i, ow + j, c}) * dZ_val;
                                    dx.at({b, oh + i, ow + j, c}) += weights_.at({i, j, c, f}) * dZ_val;
                                }
                            }
                        }
                    }
                }
            }
        }

        return dx;
    }

    Shape output_shape() const override { return output_shape_; }

    std::map<std::string, Tensor<float>> parameters() const override {
        return {{"weights", weights_}, {"bias", bias_}};
    }

    std::map<std::string, Tensor<float>> gradients() const override {
        return {{"weights", grad_weights_}, {"bias", grad_bias_}};
    }

    std::unique_ptr<Layer> clone() const override {
        return std::make_unique<Conv2D>(*this);
    }
};

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_CONVOLUTION_H