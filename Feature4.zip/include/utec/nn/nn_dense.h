#ifndef UTEC_NN_NN_DENSE_H
#define UTEC_NN_NN_DENSE_H

#include "nn_interfaces.h"
#include "nn_activation.h"
#include "utec/algebra/tensor_ops.h"
#include <stdexcept>

namespace utec::tf::layers {

class Dense : public Layer {
private:
    int units_;
    Activation activation_;
    Shape input_shape_;
    Shape output_shape_;
    Tensor<float> weights_;
    Tensor<float> bias_;

    Tensor<float> cached_input_;
    Tensor<float> cached_z_;

    Tensor<float> grad_weights_;
    Tensor<float> grad_bias_;

public:
    Dense(int units, Activation activation = Activation::Linear)
        : units_(units), activation_(activation) {
        if (units <= 0) {
            throw std::invalid_argument("Units must be greater than 0.");
        }
    }

    void build(const Shape& input_shape) override {
        input_shape_ = input_shape;
        if (input_shape_.rank() == 0) {
            throw std::invalid_argument("Input shape cannot be empty.");
        }
        int in_features = input_shape_[0];

        float val = 1.0f / static_cast<float>(in_features);
        weights_ = Tensor<float>(Shape{in_features, units_}, val);
        bias_ = Tensor<float>(Shape{units_}, 0.0f);

        grad_weights_ = Tensor<float>::zeros(weights_.shape());
        grad_bias_ = Tensor<float>::zeros(bias_.shape());

        output_shape_ = Shape{units_};
    }

    void set_weights(const Tensor<float>& w) { weights_ = w; }
    void set_bias(const Tensor<float>& b) { bias_ = b; }

    Tensor<float> forward(const Tensor<float>& x) override {
        if (x.rank() != 2) throw std::invalid_argument("Dense layer expects rank 2 input.");

        cached_input_ = x;

        Tensor<float> z = algebra::matmul(x, weights_);
        int batch = z.shape()[0];
        int units = z.shape()[1];

        for (int i = 0; i < batch; ++i) {
            for (int j = 0; j < units; ++j) {
                z.at({i, j}) += bias_.at({j});
            }
        }

        cached_z_ = z;
        return apply_activation(z, activation_);
    }

    Tensor<float> backward(const Tensor<float>& grad_output) override {
        Tensor<float> dz = apply_activation_derivative(cached_z_, activation_, grad_output);

        grad_weights_ = algebra::matmul(algebra::transpose(cached_input_), dz);

        int batch = dz.shape()[0];
        grad_bias_ = Tensor<float>::zeros(bias_.shape());
        for (int i = 0; i < batch; ++i) {
            for (int j = 0; j < units_; ++j) {
                grad_bias_.at({j}) += dz.at({i, j});
            }
        }

        return algebra::matmul(dz, algebra::transpose(weights_));
    }

    Shape output_shape() const override {
        return output_shape_;
    }

    std::map<std::string, Tensor<float>> parameters() const override {
        return {{"weights", weights_}, {"bias", bias_}};
    }

    std::map<std::string, Tensor<float>> gradients() const override {
        return {{"weights", grad_weights_}, {"bias", grad_bias_}};
    }

    std::unique_ptr<Layer> clone() const override {
        return std::make_unique<Dense>(*this);
    }
};

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_DENSE_H