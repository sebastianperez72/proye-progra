#ifndef UTEC_NN_NN_OPTIMIZER_H
#define UTEC_NN_NN_OPTIMIZER_H

#include "utec/algebra/tensor_backend.h"
#include <stdexcept>

namespace utec::tf::optimizers {

    struct SGD {
        float learning_rate;

        explicit SGD(float lr = 0.01f) : learning_rate(lr) {
            if (lr <= 0.0f) throw std::invalid_argument("Learning rate must be positive");
        }

        void update(Tensor<float>& parameter, const Tensor<float>& gradient) const {
            for (std::size_t i = 0; i < parameter.size(); ++i) {
                parameter[i] = parameter[i] - learning_rate * gradient[i];
            }
        }
    };

} // namespace utec::tf::optimizers

#endif // UTEC_NN_NN_OPTIMIZER_H