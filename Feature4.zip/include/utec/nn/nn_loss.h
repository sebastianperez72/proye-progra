#ifndef UTEC_NN_NN_LOSS_H
#define UTEC_NN_NN_LOSS_H

#include "utec/algebra/tensor_backend.h"
#include <cmath>
#include <algorithm>
#include <stdexcept>

namespace utec::tf::losses {

    class CategoricalCrossentropy {
    public:
        float operator()(const Tensor<float>& y_true, const Tensor<float>& y_pred) const {
            if (y_true.shape() != y_pred.shape()) throw std::invalid_argument("Shapes incompatibles");

            float loss = 0.0f;
            for (std::size_t i = 0; i < y_true.size(); ++i) {
                float y = y_pred.data()[i];
                y = std::max(1e-7f, std::min(1.0f - 1e-7f, y));
                loss -= y_true.data()[i] * std::log(y);
            }
            return loss / y_true.shape()[0];
        }

        Tensor<float> backward(const Tensor<float>& y_true, const Tensor<float>& y_pred) const {
            if (y_true.shape() != y_pred.shape()) throw std::invalid_argument("Shapes incompatibles");

            Tensor<float> grad = y_pred;
            for (std::size_t i = 0; i < grad.size(); ++i) {
                grad.data()[i] = (grad.data()[i] - y_true.data()[i]) / y_true.shape()[0];
            }
            return grad;
        }

        Tensor<float> gradient(const Tensor<float>& y_true, const Tensor<float>& y_pred) const {
            return backward(y_true, y_pred);
        }
    };

} // namespace utec::tf::losses

#endif // UTEC_NN_NN_LOSS_H