#ifndef UTEC_NN_NN_GRAPH_H
#define UTEC_NN_NN_GRAPH_H

#include "nn_interfaces.h"
#include <vector>
#include <memory>
#include <stdexcept>

namespace utec::tf {

    class SequentialGraph {
    private:
        std::vector<std::unique_ptr<Layer>> layers_;

    public:
        void add(std::unique_ptr<Layer> layer) {
            if (!layers_.empty()) {
                layer->build(layers_.back()->output_shape());
            }
            layers_.push_back(std::move(layer));
        }

        Tensor<float> forward(const Tensor<float>& input) {
            Tensor<float> out = input;
            for (auto& layer : layers_) {
                out = layer->forward(out);
            }
            return out;
        }

        Tensor<float> backward(const Tensor<float>& grad_output) {
            if (layers_.empty()) throw std::invalid_argument("El grafo esta vacio.");
            Tensor<float> grad = grad_output;
            for (auto it = layers_.rbegin(); it != layers_.rend(); ++it) {
                grad = (*it)->backward(grad);
            }
            return grad;
        }

        bool empty() const { return layers_.empty(); }

        const std::vector<std::unique_ptr<Layer>>& layers() const { return layers_; }
    };

} // namespace utec::tf

#endif // UTEC_NN_NN_GRAPH_H