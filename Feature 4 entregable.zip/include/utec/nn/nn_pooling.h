#ifndef UTEC_NN_NN_POOLING_H
#define UTEC_NN_NN_POOLING_H

#include "nn_interfaces.h"
#include <array>
#include <stdexcept>
#include <vector>

namespace utec::tf::layers {

class MaxPooling2D : public Layer {
private:
    std::array<int, 2> pool_size_;
    std::array<int, 2> strides_;
    Shape input_shape_;
    Shape output_shape_;

    Shape cached_input_shape_;
    std::vector<int> max_indices_;

    bool has_forward_cache_ = false; // Agregado para Test 2.2 y 7.2

public:
    explicit MaxPooling2D(std::array<int, 2> pool_size)
        : pool_size_(pool_size), strides_(pool_size) {
        if (pool_size[0] <= 0 || pool_size[1] <= 0) {
            throw std::invalid_argument("Pool size dimensions must be positive.");
        }
    }

    void build(const Shape& input_shape) override {
        input_shape_ = input_shape;
        if (input_shape_.rank() != 3) {
            throw std::invalid_argument("MaxPooling2D expects rank 3 input shape (H, W, C).");
        }

        int in_h = input_shape_[0], in_w = input_shape_[1], in_c = input_shape_[2];

        // Agregado para Test 7.2 (Verificacion de divisibilidad)
        if (in_h % pool_size_[0] != 0 || in_w % pool_size_[1] != 0) {
            throw std::invalid_argument("Input spatial dimensions must be evenly divisible by pool size.");
        }

        int out_h = in_h / pool_size_[0];
        int out_w = in_w / pool_size_[1];
        output_shape_ = Shape{out_h, out_w, in_c};
    }

    Tensor<float> forward(const Tensor<float>& x) override {
        cached_input_shape_ = x.shape();

        int batch = x.shape()[0];
        int in_h = x.shape()[1];
        int in_w = x.shape()[2];
        int channels = x.shape()[3];

        int ph = pool_size_[0], pw = pool_size_[1];
        int sh = strides_[0], sw = strides_[1];

        int out_h = (in_h - ph) / sh + 1;
        int out_w = (in_w - pw) / sw + 1;

        Tensor<float> out = Tensor<float>::zeros(Shape{batch, out_h, out_w, channels});
        int total_out_elements = batch * out_h * out_w * channels;
        max_indices_.resize(total_out_elements);
        int out_idx = 0;

        for (int b = 0; b < batch; ++b) {
            for (int oh = 0; oh < out_h; ++oh) {
                for (int ow = 0; ow < out_w; ++ow) {
                    for (int c = 0; c < channels; ++c) {
                        float max_val = x.at({b, oh * sh, ow * sw, c});
                        int max_h = 0, max_w = 0;

                        for (int kh = 0; kh < ph; ++kh) {
                            for (int kw = 0; kw < pw; ++kw) {
                                float val = x.at({b, oh * sh + kh, ow * sw + kw, c});
                                if (val > max_val) {
                                    max_val = val;
                                    max_h = kh;
                                    max_w = kw;
                                }
                            }
                        }
                        out.at({b, oh, ow, c}) = max_val;

                        int flat_idx = ((b * in_h + (oh * sh + max_h)) * in_w + (ow * sw + max_w)) * channels + c;
                        max_indices_[out_idx++] = flat_idx;
                    }
                }
            }
        }

        has_forward_cache_ = true; // Agregado para Test 2.2 y 7.2
        return out;
    }

    Tensor<float> backward(const Tensor<float>& grad_output) override {
        // Agregado para Test 2.2 y 7.2
        if (!has_forward_cache_) {
            throw std::logic_error("Cannot backward without forward pass.");
        }

        Tensor<float> dx = Tensor<float>::zeros(cached_input_shape_);

        for (std::size_t i = 0; i < grad_output.size(); ++i) {
            dx.data()[max_indices_[i]] += grad_output.data()[i];
        }
        return dx;
    }

    Shape output_shape() const override { return output_shape_; }

    std::map<std::string, Tensor<float>> parameters() const override { return {}; }
    std::map<std::string, Tensor<float>> gradients() const override { return {}; }
    std::unique_ptr<Layer> clone() const override { return std::make_unique<MaxPooling2D>(*this); }
};

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_POOLING_H