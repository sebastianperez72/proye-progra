#ifndef UTEC_NN_NEURAL_NETWORK_H
#define UTEC_NN_NEURAL_NETWORK_H

#include "nn_graph.h"
#include "nn_optimizer.h"
#include "nn_loss.h"
#include "nn_activation.h"
#include "nn_dense.h"
#include "nn_convolution.h"
#include "nn_pooling.h"
#include "nn_flatten.h"
#include "utec/algebra/tensor_backend.h"
#include "utec/algebra/tensor_ops.h"
#include <string>
#include <vector>
#include <map>
#include <stdexcept>
#include <iostream>

namespace utec::tf {

struct FitOptions {
    int epochs = 1;
    int batch_size = 32;
    bool verbose = true;
};

struct History {
    std::vector<float> loss;
};

struct EvalResult {
    float loss;
    float accuracy;
};

class Sequential {
private:
    SequentialGraph graph_;
    bool compiled_ = false;
    optimizers::SGD optimizer_;
    losses::CategoricalCrossentropy loss_fn_;

public:
    Sequential() = default;

    template <typename LayerT>
    void add(const LayerT& layer) { graph_.add(layer); }

    void compile(optimizers::SGD optimizer, losses::CategoricalCrossentropy loss_fn) {
        optimizer_ = optimizer;
        loss_fn_ = loss_fn;
        compiled_ = true;
    }

    Tensor<float> predict(const Tensor<float>& x) {
        return graph_.forward(x);
    }

    Tensor<float> backward(const Tensor<float>& grad_output) {
        if (!compiled_) throw std::logic_error("Model not compiled.");
        return graph_.backward(grad_output);
    }

    EvalResult evaluate(const Tensor<float>& x, const Tensor<float>& y) {
        if (!compiled_) throw std::logic_error("Model not compiled.");
        auto pred = predict(x);
        float loss = loss_fn_(y, pred);

        float accuracy = 0.0f;
        if (y.rank() == 2 && pred.rank() == 2) {
            int batch = y.shape()[0];
            int classes = y.shape()[1];
            int correct = 0;
            for (int i = 0; i < batch; ++i) {
                float max_y = y.at({i, 0}), max_p = pred.at({i, 0});
                int idx_y = 0, idx_p = 0;
                for (int j = 1; j < classes; ++j) {
                    if (y.at({i, j}) > max_y) { max_y = y.at({i, j}); idx_y = j; }
                    if (pred.at({i, j}) > max_p) { max_p = pred.at({i, j}); idx_p = j; }
                }
                if (idx_y == idx_p) correct++;
            }
            accuracy = static_cast<float>(correct) / batch;
        }
        return {loss, accuracy};
    }

    History fit(const Tensor<float>& x, const Tensor<float>& y, const FitOptions& options = {}) {
        if (!compiled_) throw std::logic_error("Model not compiled.");
        History history;

        for (int epoch = 0; epoch < options.epochs; ++epoch) {
            auto pred = graph_.forward(x);
            float epoch_loss = loss_fn_(y, pred);

            auto grad = loss_fn_.backward(y, pred);
            graph_.backward(grad);

            // Entrenamiento: Actualización dinámica (Test 11.1)
            for (auto& layer_ptr : graph_.layers()) {
                auto params = layer_ptr->parameters();
                auto grads = layer_ptr->gradients();

                for (const auto& [name, tensor] : params) {
                    Tensor<float> w = tensor;
                    optimizer_.update(w, grads.at(name)); // Aplicar SGD

                    if (name == "weights") {
                        if (auto dense = dynamic_cast<layers::Dense*>(layer_ptr.get())) dense->set_weights(w);
                        else if (auto conv = dynamic_cast<layers::Conv2D*>(layer_ptr.get())) conv->set_weights(w);
                    } else if (name == "bias") {
                        if (auto dense = dynamic_cast<layers::Dense*>(layer_ptr.get())) dense->set_bias(w);
                        else if (auto conv = dynamic_cast<layers::Conv2D*>(layer_ptr.get())) conv->set_bias(w);
                    }
                }
            }
            history.loss.push_back(epoch_loss);
        }
        return history;
    }

    // Exponer parámetros nombrados correctamente (Test 11.1)
    std::map<std::string, Tensor<float>> parameters() const {
        std::map<std::string, Tensor<float>> params;
        int conv_idx = 0;
        int dense_idx = 0;

        for (const auto& layer : graph_.layers()) {
            std::string prefix;
            if (dynamic_cast<layers::Conv2D*>(layer.get())) {
                prefix = "conv2d_" + std::to_string(conv_idx++) + "/";
            } else if (dynamic_cast<layers::Dense*>(layer.get())) {
                prefix = "dense_" + std::to_string(dense_idx++) + "/";
            } else {
                continue;
            }

            for (const auto& [name, tensor] : layer->parameters()) {
                params[prefix + name] = tensor;
            }
        }
        return params;
    }

    // Exponer gradientes con los mismos prefijos (Test 11.2)
    std::map<std::string, Tensor<float>> last_gradients() const {
        std::map<std::string, Tensor<float>> grads;
        int conv_idx = 0;
        int dense_idx = 0;

        for (const auto& layer : graph_.layers()) {
            std::string prefix;
            if (dynamic_cast<layers::Conv2D*>(layer.get())) {
                prefix = "conv2d_" + std::to_string(conv_idx++) + "/";
            } else if (dynamic_cast<layers::Dense*>(layer.get())) {
                prefix = "dense_" + std::to_string(dense_idx++) + "/";
            } else {
                continue;
            }

            for (const auto& [name, tensor] : layer->gradients()) {
                grads[prefix + name] = tensor;
            }
        }
        return grads;
    }
};

} // namespace utec::tf

#endif // UTEC_NN_NEURAL_NETWORK_H