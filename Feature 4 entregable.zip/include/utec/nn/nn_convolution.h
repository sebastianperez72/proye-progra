#ifndef UTEC_NN_NN_CONVOLUTION_H
#define UTEC_NN_NN_CONVOLUTION_H

#include "nn_interfaces.h"
#include "nn_activation.h"
#include "nn_ops.h"
#include <array>
#include <stdexcept>

namespace utec::tf::layers {

class Conv2D : public Layer {
private:
    int filters_;
    std::array<int, 2> kernel_size_;
    Activation activation_;
    Shape input_shape_;
    Shape output_shape_;
    Tensor<float> weights_;
    Tensor<float> bias_;

    Tensor<float> cached_input_;
    Tensor<float> cached_z_;
    Tensor<float> grad_weights_;
    Tensor<float> grad_bias_;

    // Flag agregado para requerir un forward antes de un backward
    bool has_forward_cache_ = false;

public:
    Conv2D(int filters, std::array<int, 2> kernel_size, Activation activation = Activation::Linear)
        : filters_(filters), kernel_size_(kernel_size), activation_(activation) {
        if (filters <= 0 || kernel_size[0] <= 0 || kernel_size[1] <= 0) {
            throw std::invalid_argument("Filters and kernel sizes must be positive.");
        }
    }

    void build(const Shape& input_shape) override {
        input_shape_ = input_shape;
        if (input_shape_.rank() != 3) throw std::invalid_argument("Conv2D expects rank 3 input shape (H, W, C).");

        int in_h = input_shape_[0];
        int in_w = input_shape_[1];
        int in_c = input_shape_[2];
        int kh = kernel_size_[0];
        int kw = kernel_size_[1];

        float val = 1.0f / static_cast<float>(kh * kw * in_c);
        weights_ = Tensor<float>(Shape{kh, kw, in_c, filters_}, val);
        bias_ = Tensor<float>::zeros(Shape{filters_});

        int out_h = in_h - kh + 1;
        int out_w = in_w - kw + 1;
        output_shape_ = Shape{out_h, out_w, filters_};
    }

    Tensor<float> forward(const Tensor<float>& x) override {
        cached_input_ = x;

        // Llamada a la operación matemática base definida en nn_ops.h
        Tensor<float> z = utec::tf::ops::conv2d(x, weights_);

        int batch = z.shape()[0];
        int out_h = z.shape()[1];
        int out_w = z.shape()[2];
        int out_c = z.shape()[3];

        for (int b = 0; b < batch; ++b) {
            for (int oh = 0; oh < out_h; ++oh) {
                for (int ow = 0; ow < out_w; ++ow) {
                    for (int oc = 0; oc < out_c; ++oc) {
                        z.at({b, oh, ow, oc}) += bias_.at({oc});
                    }
                }
            }
        }

        cached_z_ = z;
        has_forward_cache_ = true; // Caché guardado exitosamente
        return apply_activation(z, activation_);
    }

    Tensor<float> backward(const Tensor<float>& grad_output) override {
        // Validación obligatoria requerida por las pruebas
        if (!has_forward_cache_) {
            throw std::logic_error("Cannot backward without forward pass.");
        }

        Tensor<float> dz = apply_activation_derivative(cached_z_, activation_, grad_output);

        int batch = dz.shape()[0];
        int out_h = dz.shape()[1];
        int out_w = dz.shape()[2];
        int filters = dz.shape()[3];

        int in_c = input_shape_[2];
        int kh = kernel_size_[0];
        int kw = kernel_size_[1];

        grad_weights_ = Tensor<float>::zeros(weights_.shape());
        grad_bias_ = Tensor<float>::zeros(bias_.shape());
        Tensor<float> dx = Tensor<float>::zeros(cached_input_.shape());

        for (int b = 0; b < batch; ++b) {
            for (int oh = 0; oh < out_h; ++oh) {
                for (int ow = 0; ow < out_w; ++ow) {
                    for (int f = 0; f < filters; ++f) {
                        float dZ_val = dz.at({b, oh, ow, f});
                        grad_bias_.at({f}) += dZ_val;

                        for (int i = 0; i < kh; ++i) {
                            for (int j = 0; j < kw; ++j) {
                                for (int c = 0; c < in_c; ++c) {
                                    grad_weights_.at({i, j, c, f}) += cached_input_.at({b, oh + i, ow + j, c}) * dZ_val;
                                    dx.at({b, oh + i, ow + j, c}) += weights_.at({i, j, c, f}) * dZ_val;
                                }
                            }
                        }
                    }
                }
            }
        }

        return dx;
    }

    Shape output_shape() const override { return output_shape_; }

    std::map<std::string, Tensor<float>> parameters() const override {
        return {{"weights", weights_}, {"bias", bias_}};
    }

    std::map<std::string, Tensor<float>> gradients() const override {
        return {{"weights", grad_weights_}, {"bias", grad_bias_}};
    }

    std::unique_ptr<Layer> clone() const override {
        return std::make_unique<Conv2D>(*this);
    }

    // --- SETTERS SOLICITADOS ---
    void set_weights(const Tensor<float>& w) { weights_ = w; }
    void set_bias(const Tensor<float>& b) { bias_ = b; }
};

} // namespace utec::tf::layers

#endif // UTEC_NN_NN_CONVOLUTION_H