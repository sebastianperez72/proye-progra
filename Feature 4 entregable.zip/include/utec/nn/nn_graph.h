#ifndef UTEC_NN_NN_GRAPH_H
#define UTEC_NN_NN_GRAPH_H

#include "nn_interfaces.h"
#include <vector>
#include <memory>
#include <stdexcept>

namespace utec::tf {

    class SequentialGraph {
    private:
        std::vector<std::unique_ptr<Layer>> layers_;

    public:
        template <typename LayerT>
        void add(const LayerT& layer) {
            auto cloned = layer.clone();
            // Si la capa aún no se ha construido, y tenemos una capa anterior construida, la construimos.
            if (!layers_.empty() && cloned->output_shape().rank() == 0) {
                if (layers_.back()->output_shape().rank() > 0) {
                    cloned->build(layers_.back()->output_shape());
                }
            }
            layers_.push_back(std::move(cloned));
        }

        void add(std::unique_ptr<Layer> layer) {
            // Misma lógica para punteros únicos
            if (!layers_.empty() && layer->output_shape().rank() == 0) {
                if (layers_.back()->output_shape().rank() > 0) {
                    layer->build(layers_.back()->output_shape());
                }
            }
            layers_.push_back(std::move(layer));
        }

        Tensor<float> forward(const Tensor<float>& input) {
            // Deferred build: Construcción tardía (estilo Keras) en el primer forward
            // Útil si la primera capa no fue pre-construida por el usuario.
            if (!layers_.empty() && layers_.front()->output_shape().rank() == 0) {
                layers_.front()->build(input.shape());
                for (std::size_t i = 1; i < layers_.size(); ++i) {
                    if (layers_[i]->output_shape().rank() == 0) {
                        layers_[i]->build(layers_[i-1]->output_shape());
                    }
                }
            }

            Tensor<float> out = input;
            for (auto& layer : layers_) {
                out = layer->forward(out);
            }
            return out;
        }

        Tensor<float> backward(const Tensor<float>& grad_output) {
            if (layers_.empty()) throw std::invalid_argument("El grafo esta vacio.");
            Tensor<float> grad = grad_output;
            // El backward viaja en reverso por la red
            for (auto it = layers_.rbegin(); it != layers_.rend(); ++it) {
                grad = (*it)->backward(grad);
            }
            return grad;
        }

        bool empty() const { return layers_.empty(); }

        const std::vector<std::unique_ptr<Layer>>& layers() const { return layers_; }
    };

} // namespace utec::tf

#endif // UTEC_NN_NN_GRAPH_H