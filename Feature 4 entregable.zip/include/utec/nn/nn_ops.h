#ifndef UTEC_NN_NN_OPS_H
#define UTEC_NN_NN_OPS_H

#include "utec/algebra/tensor_ops.h"
#include "utec/algebra/tensor_backend.h"

namespace utec::tf {
    struct Strides { int h = 1; int w = 1; };
    enum class Padding { Valid, Same };
}

namespace utec::tf::ops {

    template <typename T>
    Tensor<T> matmul(const Tensor<T>& a, const Tensor<T>& b) {
        return utec::tf::algebra::matmul(a, b);
    }

    template <typename T>
    Tensor<T> transpose(const Tensor<T>& a) {
        return utec::tf::algebra::transpose(a);
    }

    inline Tensor<float> conv2d(const Tensor<float>& input, const Tensor<float>& kernel, Strides strides = Strides{1, 1}, Padding padding = Padding::Valid) {
        int batch = input.shape()[0], in_h = input.shape()[1], in_w = input.shape()[2], in_c = input.shape()[3];
        int kh = kernel.shape()[0], kw = kernel.shape()[1], out_c = kernel.shape()[3];

        // Asumiendo Padding::Valid como baseline
        int out_h = (in_h - kh) / strides.h + 1;
        int out_w = (in_w - kw) / strides.w + 1;

        Tensor<float> out = Tensor<float>::zeros(Shape{batch, out_h, out_w, out_c});
        for (int b = 0; b < batch; ++b) {
            for (int oh = 0; oh < out_h; ++oh) {
                for (int ow = 0; out_w > ow; ++ow) {
                    for (int oc = 0; oc < out_c; ++oc) {
                        float sum = 0.0f;
                        for (int i = 0; i < kh; ++i) {
                            for (int j = 0; j < kw; ++j) {
                                for (int ic = 0; ic < in_c; ++ic) {
                                    sum += input.at({b, oh * strides.h + i, ow * strides.w + j, ic}) * kernel.at({i, j, ic, oc});
                                }
                            }
                        }
                        out.at({b, oh, ow, oc}) = sum;
                    }
                }
            }
        }
        return out;
    }

} // namespace utec::tf::ops

#endif // UTEC_NN_NN_OPS_H