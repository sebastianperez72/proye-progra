#ifndef UTEC_ALGEBRA_TENSOR_BACKEND_H
#define UTEC_ALGEBRA_TENSOR_BACKEND_H

#include "shape.h"
#include <vector>
#include <stdexcept>
#include <array>

namespace utec::tf {

template <typename T>
class Tensor {
private:
    Shape shape_;
    std::vector<T> data_;

    Tensor(Shape s, std::vector<T> d) : shape_(std::move(s)), data_(std::move(d)) {}

    template <std::size_t N>
    std::size_t compute_index(const std::array<int, N>& indices) const {
        if (N != shape_.rank()) throw std::invalid_argument("Cantidad de indices no coincide.");
        std::size_t flat_idx = 0;
        std::size_t stride = 1;
        for (int i = shape_.rank() - 1; i >= 0; --i) {
            if (indices[i] < 0 || indices[i] >= shape_[i]) throw std::out_of_range("Indice fuera de limites.");
            flat_idx += indices[i] * stride;
            stride *= shape_[i];
        }
        return flat_idx;
    }

public:
    static Tensor zeros(const Shape& s) { return Tensor(s, std::vector<T>(s.numel(), T(0))); }
    static Tensor ones(const Shape& s) { return Tensor(s, std::vector<T>(s.numel(), T(1))); }
    static Tensor from_data(const Shape& s, const std::vector<T>& data) {
        if (data.size() != s.numel()) throw std::invalid_argument("Datos no coinciden con numel().");
        return Tensor(s, data);
    }

    std::size_t rank() const { return shape_.rank(); }
    std::size_t numel() const { return shape_.numel(); }
    Shape shape() const { return shape_; }
    const std::vector<T>& data() const { return data_; }

    template <typename... Args>
    T& operator()(Args... args) {
        std::array<int, sizeof...(Args)> indices = { static_cast<int>(args)... };
        return data_[compute_index(indices)];
    }

    template <typename... Args>
    const T& operator()(Args... args) const {
        std::array<int, sizeof...(Args)> indices = { static_cast<int>(args)... };
        return data_[compute_index(indices)];
    }

    Tensor reshape(const Shape& new_shape) const {
        if (new_shape.numel() != this->numel()) throw std::invalid_argument("Nuevo Shape no preserva numel.");
        return Tensor(new_shape, data_);
    }

    Tensor operator+(const Tensor& other) const {
        if (shape_ != other.shape_) throw std::invalid_argument("Shapes incompatibles para suma.");
        std::vector<T> new_data(data_.size());
        for (std::size_t i = 0; i < data_.size(); ++i) new_data[i] = data_[i] + other.data_[i];
        return Tensor(shape_, std::move(new_data));
    }

    Tensor operator-(const Tensor& other) const {
        if (shape_ != other.shape_) throw std::invalid_argument("Shapes incompatibles para resta.");
        std::vector<T> new_data(data_.size());
        for (std::size_t i = 0; i < data_.size(); ++i) new_data[i] = data_[i] - other.data_[i];
        return Tensor(shape_, std::move(new_data));
    }
};

} // namespace utec::tf

#endif // UTEC_ALGEBRA_TENSOR_BACKEND_H